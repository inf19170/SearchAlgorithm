
Grundsätzlich sollte der Algorithmus von allen Start-/Zielpositionen aus laufen.

Testen Sie mindestens mit:

Start (4,4)
Ziel  (17,28)

Obere linke Bildecke = (0,0)


Wegekosten

5 = Wasser

3 = Wiese

2 = Weg

20 = bergiges Gelände

11 = Wald